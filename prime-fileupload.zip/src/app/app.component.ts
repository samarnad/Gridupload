import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit  {

  parties: Party[];

    selectedParty: Party;

    

    constructor() {
        this.parties = [
            {name: 'ARCH MRT', code: 'AR'},
            {name: 'MGIC', code: 'MG'}
        ];

        
    }

  name = 'Pricing Grid';

  public ngOnInit() {
    
  }

  uploadedFiles: any[] = [];

  myUploader(event) {
    for(let file of event.files) {
      this.uploadedFiles.push(file);
    }

    console.log('UPLOAD', event);
  }

  mySelect(event){
    console.log('SELECT', event);
  }
}
